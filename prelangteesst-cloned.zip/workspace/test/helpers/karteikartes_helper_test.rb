require 'test_helper'

class KarteikartesHelperTest < ActionView::TestCase
end
