require 'test_helper'

class KarteikarteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
