class Karteikarte < ActiveRecord::Base
  belongs_to :user
  acts_as_votable 
  
  #Pflichtangaben beim erstellen einer Karteikarte
  validates_presence_of :titel, :vorderseite, :rueckseite
end
