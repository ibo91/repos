class KarteikartesController < ApplicationController

  #->Prelang (scaffolding:rails/scope_to_user)
  before_filter :require_user_signed_in, only: [:new, :edit, :create, :update, :destroy]

  before_action :set_karteikarte, only: [:show, :edit, :update, :destroy, :vote]

  # GET /karteikartes
  # GET /karteikartes.json
  def index
    if (request.path == "/karteikartes")  # WENN der hintere Teil der URL == "/karteikartes"
      @karteikartes = Karteikarte.all     # DANN ermittel alle Karteikarten
      @title = "Alle Karteikarten"        # Setze den Titel auf der Seite auf "Alle Karteikarten"
    else
      # @karteikartes = Karteikarte.where(karteikartes: {titel: "params"})
      @karteikartes = Karteikarte.joins(:user).where(users: {id: current_user})   # Sonst zeige nur die Karteikarten des eingeloggten Nutzers
      @title = "Meine Karteikarten"                                               # Setze den Titel der Seite auf "Meine Karteikarten"
    end
  end

  def modulwahl
    @karteikartes = Karteikarte.select(:titel).distinct
  end
  
  def abfragestarten

  end

  # GET /karteikartes/1
  # GET /karteikartes/1.json
  def show
    
  end

  # GET /karteikartes/new
  def new
    @karteikarte = Karteikarte.new
  end

  # GET /karteikartes/1/edit
  def edit
  end

  # POST /karteikartes
  # POST /karteikartes.json
  def create
    @karteikarte = Karteikarte.new(karteikarte_params)
    @karteikarte.user = current_user

    respond_to do |format|
      if @karteikarte.save
        format.html { redirect_to @karteikarte, notice: 'Karteikarte was successfully created.' }
        format.json { render :show, status: :created, location: @karteikarte }
      else
        format.html { render :new }
        format.json { render json: @karteikarte.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /karteikartes/1
  # PATCH/PUT /karteikartes/1.json
  def update
    respond_to do |format|
      if @karteikarte.update(karteikarte_params)
        format.html { redirect_to @karteikarte, notice: 'Karteikarte was successfully updated.' }
        format.json { render :show, status: :ok, location: @karteikarte }
      else
        format.html { render :edit }
        format.json { render json: @karteikarte.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /karteikartes/1
  # DELETE /karteikartes/1.json
  def destroy
    @karteikarte.destroy
    respond_to do |format|
      format.html { redirect_to karteikartes_url, notice: 'Karteikarte was successfully destroyed.' }
      format.json { head :no_content }
    end
  end


  #->Prelang (voting/acts_as_votable)
  def vote

    direction = params[:direction]

    # Make sure we've specified a direction
    raise "No direction parameter specified to #vote action." unless direction

    # Make sure the direction is valid
    unless ["like", "bad"].member? direction
      raise "Direction '#{direction}' is not a valid direction for vote method."
    end

    @karteikarte.vote_by voter: current_user, vote: direction

    redirect_to action: :index
  end


  private
    # Use callbacks to share common setup or constraints between actions.
    def set_karteikarte
      @karteikarte = Karteikarte.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def karteikarte_params
      params.require(:karteikarte).permit(:titel, :vorderseite, :rueckseite, :user_id)
    end
end
